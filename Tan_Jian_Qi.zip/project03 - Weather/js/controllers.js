angular.module('app.controllers', [])
  
.controller('weatherCtrl', function($scope) {
    
})
   
.controller('addCityCtrl', function($scope) {
    
   
})
   
.controller('weatherDetailCtrl', function($scope) {

})
 